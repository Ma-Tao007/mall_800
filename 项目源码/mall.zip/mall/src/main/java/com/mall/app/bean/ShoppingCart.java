package com.mall.app.bean;

public class ShoppingCart {
private int productId;
private Goods goods;
private int buyerId;
private double price;
private double pprice;
private int num;
public double getPprice() {
		return pprice;
	}
public void setPprice(double pprice) {
	this.pprice = pprice;
}
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public int getBuyerId() {
	return buyerId;
}
public void setBuyerId(int buyerId) {
	this.buyerId = buyerId;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getNum() {
	return num;
}
public void setNum(int num) {
	this.num = num;
}
public Goods getGoods() {
	return goods;
}
public void setGoods(Goods goods) {
	this.goods = goods;
}


}
