package com.mall.app.test;

import org.junit.Test;

import com.mall.app.service.ListProductService;
import com.mall.app.service.impl.ListProductServiceImpl;

public class ListProductServiceTest {
	ListProductService listProductService = new ListProductServiceImpl();
	
	@Test
	public void ListProductServiceFunctionTest(){
	}
}
